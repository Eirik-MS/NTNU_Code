#pragma once

namespace TDT4102 {
    enum class Font {
        defaultFont,

        arial,
        arial_bold,
        arial_italic,
        arial_bold_italic,

        courier,
        courier_bold,
        courier_italic,
        courier_bold_italic,

        times,
        times_bold,
        times_italic,
        times_bold_italic
    };
}
