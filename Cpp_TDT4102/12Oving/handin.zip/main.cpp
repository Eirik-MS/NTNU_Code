#include "Tetromino.h"
#include "TetrisWindow.h"



int main()
{
	
		TetrisWindow window;
		window.run();
    
	return 0;
}
