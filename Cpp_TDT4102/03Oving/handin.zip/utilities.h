#include "std_lib_facilities.h"

int randomWithLimits(int lowerLimit, int upperLimit);