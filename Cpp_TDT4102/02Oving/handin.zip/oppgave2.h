
#include "std_lib_facilities.h"
#include "oppgave1.h"

int sumOfManyInt();
int sumOfManyInt2();
double inputDouble();
double NOKtoEUR();
void ganngetabell();
