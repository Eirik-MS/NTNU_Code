
#include "std_lib_facilities.h"

vector<int> calculateBalance(int inskudd, int rente, int antallAar);
void printBalance(vector<int> balance);