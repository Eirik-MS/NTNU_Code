
#include "std_lib_facilities.h"
#include "AnimationWindow.h"
#include "oppgave1.h"
#include "oppgave2.h"
#include "oppgave3.h"


void pythagoras();