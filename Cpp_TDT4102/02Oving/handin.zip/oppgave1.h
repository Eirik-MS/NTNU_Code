// Purpose: Header file for oppgave1.cpp

#include "std_lib_facilities.h"

void inputIntegersAndPrintProduct();
int add(int a, int b);
void inputIntegersAndPrint();
int inputInteger();
void inputIntegersAndPrintSum();
bool isOdd(int x);
void printHumanReadableTime(int seconds);

