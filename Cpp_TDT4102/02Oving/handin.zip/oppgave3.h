
#include "std_lib_facilities.h"
#include "oppgave1.h"
#include "oppgave2.h"


int discriminant(int a, int b, int c);
void printRealRoots(int a, int b, int c);
void solveQuadraticEquation();
