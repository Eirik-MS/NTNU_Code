print("Dette er mitt første program i jupyter") #endre denne linjen
print("Nå skal programmet stille et spørsmål\n")
navn = input("Hva heter du? \n")
print("Hei ", navn)

alder = int(input("Hvor gammel er du? \n")) # Her må du kun skrive et tall
print("Da er du", alder + 5, "år gammel når du er ferdig på studiet.")

message = "Wow! Jupyter var kult!"

